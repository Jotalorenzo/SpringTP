export interface ClienteDTO {
  id: number;
  cuitCuil?: string;
  denominacion?: string;
}

export interface ArticuloPrecioDTO {
  articuloId: number;
  listaPrecioArticuloId: number;
  codigo: string;
  denominacion: string;
  precioVenta: number;
}

export interface PuntoVentaDTO {
  id: number;
  numero: number;
  descripcion?: string;
  domicilioComercial?: string;
}

export interface TipoMonedaDTO {
  id: number;
  codigoAfip?: string;
  denominacion: string;
  simbolo?: string;
}

export interface ListaPrecioDTO {
  id: number;
  codigo: string;
  denominacion: string;
}

export interface CondicionIvaDTO {
  id: number;
  codigoAfip: number;
  denominacion: string;
}

export interface FacturaDetalleRequestDTO {
  articuloId: number;
  cantidad: number;
  descripcion?: string;
  porcentajeBonificacion?: number;
}

export interface FacturaRequestDTO {
  numero?: number;
  fechaEmision: string;
  puntoVentaId: number;
  condicionIvaId: number;
  tipoMonedaId: number;
  listaPrecioId: number;
  letra: string;
  clienteId?: number | null;
  detalles: FacturaDetalleRequestDTO[];
}

export interface FacturaReporteDTO {
  id: number;
  numeroFactura?: number;
  fechaEmision: string;
  clienteDenominacion: string;
  condicionIva: string;
  puntoVentaDescripcion: string;
  importeTotal: number;
  cantidadItems: number;
  estado: string;
  cae?: string;
}

export interface PaginaDTO<T> {
  contenido: T[];
  pagina: number;
  tamanio: number;
  totalElementos: number;
  totalPaginas: number;
}

export interface FacturaVentaDetalleDTO {
  id?: number;
  articuloId: number;
  articuloDenominacion: string;
  descripcion?: string;
  cantidad: number;
  precioUnitario: number;
  importeSubtotal: number;
}

export interface FacturaVentaDTO {
  id: number;
  numero?: number;
  fechaEmision: string;
  puntoVentaId: number;
  clienteId?: number;
  clienteDenominacion?: string;
  tipoMonedaId: number;
  condicionIvaId: number;
  importeTotal: number;
  cae?: string;
  estado: string;
  detalles: FacturaVentaDetalleDTO[];
}
